#ifndef HEADER_H
#define HEADER_H


typedef struct podatci {

	char ime[20];
	char prezime[30];
	long OIB;
	char datumRodenja;

}PODATCI;

typedef struct parametri {

	short brojRoditelja;
	short brojBraceISestara;
	short zaposleniRoditelj;
	short posebnePotrebe;
	short dijeteIznad4Godine;
	
	int zbrojBodova;


};

void kreiranjeDatoteke(const char* const imeDatoteke);
int izbornik(const char* const imeDatoteke);

#endif // !HEADER_H

