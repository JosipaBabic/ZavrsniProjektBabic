﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Header.h"

int main(void) {

	char imeDatoteke = { "informacijeDjece" };
	int uvijet = 1;
	PODATCI* dijete = NULL;
	kreiranjeDatoteke(imeDatoteke);

	/*while (uvijet) {
		uvijet = izbornik();
	}
	printf("Zavretak programa!\n");
	return 0;*/
}