﻿#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Header.h"

static int brClanova = 0;



void kreiranjeDatoteke(const char* const imeDatoteke) {

	FILE* pF = fopen(imeDatoteke, "a");
	pF = fopen("informacijeDjece.txt", "a");
	if (pF == NULL) {
		printf("Greska pri otvaranju datoteke!\n");
		exit(1);
	}
	fwrite(&brClanova, sizeof(int), 1, pF);
	fclose(pF);
}

//napraviti mogućnost edita ukoliko netko krivo unese i u iščitavanju se vidi greška u unesenim podatcima
//
//int izbornik(const char* const imeDatoteke) {
//	printf("====================");
//	printf("Odaberite jednu od ponudenih opcija:");
//	printf("====================\n");
//	printf("\t\t\tOpcija 1: kreiranje datoteke!\n");
//	printf("\t\t\tOpcija 2: dodavanje informacija djeteta!\n");
//	printf("\t\t\tOpcija 3: ucitavanje informacija djeteta!\n");
//	printf("\t\t\tOpcija 4: ispisivanje informacija djeteta!\n");
//	printf("\t\t\tOpcija 5: pretrazivanje informacija djeteta!\n");
//	printf("\t\t\tOpcija 6: brisanje informacija djeteta!\n");
//	printf("\t\t\tOpcija 7: promjena imena datoteci!\n");
//	printf("\t\t\tOpcija 8: brisanje datoteke!\n");
//	printf("\t\t\tOpcija 9: izlaz iz programa!\n");
//	printf("======================================\
//======================================\n");
//	int uvijet = 0;
//	
//	scanf("%d", &uvijet);
//	switch (uvijet) {
//	case 1:
//		kreiranjeDatoteke();
//	case 2:
//		
//	case 3:
//		
//	case 4:
//		
//	case 5:
//		
//
//	default:
//		uvijet = 0;
//	}
//	return uvijet;
//}
//
//void unosPodatakaDjece(char imeDatoteke) {
//
//	printf("Unesite ime djeteta:");
//	PODATCI*dijete;
//	int i;
//	char fp;
//
//	fp = fopen("informacijeDjece.txt", "a");
//	if (fp == NULL) {
//		printf("Greska pri otvaranju datoteke!\n");
//		exit(1);
//	}
//
//	for (i = 1; i <= n; i++) {
//		printf("Unesite ime i prezime studenta %d: ", i);
//		scanf("%s %s", ime, prezime);
//		fprintf(fp, "Student broj: %d.\tIme: %s\t Prezime: %s\n", i, ime, prezime);
//	}
//
//	fclose(fp);
//}
//
//}