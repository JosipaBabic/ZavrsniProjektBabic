#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "Header.h"



int main() {

    FILE* datoteka;
    char imeDatoteke[10] = "vrtic.txt";
   

    otvoriDatoteku(&datoteka, imeDatoteke, "a+");

    while (1){

        izbornik(imeDatoteke);

   }

    return 0;
}




